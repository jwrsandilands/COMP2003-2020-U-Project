﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cast : MonoBehaviour
{

    public Animator castAnimation;

    private bool casting;
    private float atHookTime = 0.9f;
    private float atHook;


    public Transform castPoint;
    public GameObject hookprefab;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            casting = true;
            CastHookAnim();
            
        }

        if(casting && Time.time > atHook)
        {
            
            CastHook();
           
            casting = false;
            
            
        }
    }

    void CastHookAnim()
    {
        castAnimation.Play("Cast");
        atHook = Time.time + atHookTime;
        casting = true;
        
        
    }

    void CastHook()
    {
        Instantiate(hookprefab, castPoint.position, castPoint.rotation);
    }
}
